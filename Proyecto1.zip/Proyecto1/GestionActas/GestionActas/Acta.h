#pragma once
#include "TipoTrabajo.h"
#include "EstadoTrabajo.h"
#include "Estado.h"
#include "Observacion.h"
#include "Jurado.h"
#include <string>
using namespace std;

class Acta
{
private:
	int numero;
	string fecha;
	string autor;
	string nombreTrabajo;
	TipoTrabajo tipoTrabajo;
	int periodo;
	string director;
	string codirector;
	double notaFinal;
	Estado estado;
	EstadoTrabajo estadoTrabajo;
    vector<Observacion> observaciones;
    Jurado jurado1;
    Jurado jurado2;

public:

    Acta(int numero, string fecha, string autor, string nombretrabajo, TipoTrabajo tipoTrabajo,int periodo ,string director, string codirector, Jurado jurado1,
        Jurado jurado2) {
        this->numero = numero;
        this->fecha = fecha;
        this->autor = autor;
        this->nombreTrabajo = nombretrabajo;
        this->tipoTrabajo = tipoTrabajo;
        this->periodo = periodo;
        this->director = director;
        this->codirector = codirector;
        this->estado = Estado::abierto;
        this->estadoTrabajo = EstadoTrabajo::pendiente;
        this->jurado1 = jurado1;
        this->jurado2 = jurado2;
    };
 
    int getNumero() {
        return this->numero;
    }
    void setNumero(int numero) {
        this->numero = numero;
    }


    string getFecha() {
        return this->fecha;
    }
    void setFecha(string fecha) {
        this->fecha = fecha;
    }


    string getAutor() {
        return this->autor;
    }
    void setAutor(string autor) {
        this->autor = autor;
    }


    string getNombreTrabajo() {
        return this->nombreTrabajo;
    }
    void setNombreTrabajo(string nombreTrabajo) {
        this->nombreTrabajo = nombreTrabajo;
    }


    TipoTrabajo getTipoTrabajo() {
        return this->tipoTrabajo;
    }
    void setTipoTrabajo(TipoTrabajo tipoTrabajo) {
        this->tipoTrabajo = tipoTrabajo;
    }


    int getPeriodo() {
        return this->periodo;
    }
    void setPeriodo(int periodo) {
        this->periodo = periodo;
    }


    string getDirector() {
        return this->director;
    }
    void setDirector(string director) {
        this->director = director;
    }


    string getCodirector() {
        return this->codirector;
    }
    void setCodirector(string codirector) {
        this->codirector = codirector;
    }


    double getNotaFinal() {
        return this->notaFinal;
    }
    void setNotaFinal(double notaFinal) {
        this->notaFinal = notaFinal;
    }



    Estado getEstado() {
        return this->estado;
    }
    void setEstado(Estado estado) {
        this->estado = estado;
    }


    EstadoTrabajo getEstadoTrabajo() {
        return this->estadoTrabajo;
    }
    void setEstadoTrabajo(EstadoTrabajo estadoTrabajo) {
        this->estadoTrabajo = estadoTrabajo;
    }

    vector<Observacion> getObservaciones() {
        return this->observaciones;
    }
    void setObservaciones(vector<Observacion> observaciones) {
        this->observaciones = observaciones;
    }


    Jurado getJurado1() {
        return this->jurado1;
    }
    void setJurado1(Jurado jurado1) {
        this->jurado1 = jurado1;
    }


    Jurado getJurado2() {
        return this->jurado2;
    }
    void setJurado2(Jurado jurado2) {
        this->jurado2 = jurado2;
    }

};


