
#include <iostream>
#include "Acta.h"
#include "Jurado.h"
#include "CriterioEvaluacion.h"
#include "Observacion.h"
#include <string>
#include <vector>

using namespace std;

vector<Acta> actas;
vector<Jurado> jurados;
vector<CriterioEvaluacion> criteriosEvaluacion;

void cargarInfo()
{

}

void crearNuevaActa()
{

}

Acta buscarActaPorNumero(int numeroActa)
{

}

void calcularNotaFinal()
{

}

void diligenciarCalificaciones()
{

}

void cerrarActa()
{

}

void guardarActaTxt(Acta acta)
{

}

void eliminarActa(int numeroActa)
{

}

void mostrarActas()
{

}

void mostrarActasAbiertas() {

}
void mostrarActasCerradas() {

}
void mostrarTrabajosAplicados() {

}
void mostrarTrabajosInvestigacion() {

}
void mostrarTrabajosDirigidosProfesor() {

}
void cargarInfo() {

}
void trabajosPorJurado() {

}
void mostrarJurados() {

}
void mostrarTrabajosPendientes() {

}
void mostrarTrabajosRechazados() {

}

void submenuConsultaActas()
{
	int opcion;
	do
	{
		cout << "Consulta actas\n"
			"1. Mostrar todas las actas\n"
			"2. Mostrar actas abiertas\n"
			"3. Mostrar actas cerradas\n"
			"0. Menu anterior\n"
			;

		cin >> opcion;
		switch (opcion)
		{
		case(1):
			mostrarActas();
			break;
		case(2):
			mostrarActasAbiertas();
			break;
		case(3):
			mostrarActasCerradas();
			break;
		default:
			break;
		}
	} while (opcion > 0);
}

void submenuConsultaTrabajos()
{
	int opcion;
	do
	{
		cout << "Consulta trabajos\n"
			"1. Mostrar trabajos aplicados\n"
			"2. Mostrar trabajos investigacion\n"
			"3. Mostrar trabajos pendientes\n"
			"4. Mostrar trabajos rechazados\n"
			"5. Mostrar trabajos dirigidos por un profesor por nombre\n"
			"0. Menu anterior\n"
			;

		cin >> opcion;
		switch (opcion)
		{
		case(1):
			mostrarTrabajosAplicados();
			break;
		case(2):
			mostrarTrabajosInvestigacion();
			break;
		case(3):
			mostrarTrabajosPendientes();
			break;
		case(4):
			mostrarTrabajosRechazados();
			break;
		case(5):
			mostrarTrabajosDirigidosProfesor();
			break;
		default:
			break;
		}
	} while (opcion > 0);
}

void submenuConsultaJurados()
{
	int opcion;
	do
	{
		cout << "Consulta jurados"
			"1. Mostrar trabajos por jurado\n"
			"2. Mostrar todos los jurados\n"
			"0. Menu anterior\n"
			;

		cin >> opcion;
		switch (opcion)
		{
		case(1):
			trabajosPorJurado();
			break;
		case(2):
			mostrarJurados();
			break;

		default:
			break;
		}
	} while (opcion > 0);
}


int main()
{
	cargarInfo();
	int opcion;
	do
	{
		cout << "Digite el numero de la opcion que desee llevar a cabo\n"
			"1. Crear nueva acta\n"
			"2. Calcular nota final acta\n"
			"3. Diligenciar calificaciones acta\n"
			"4. Cerrar acta\n"
			"5. Consulta actas\n"
			"6. Consulta trabajos\n"
			"7. Consulta jurados\n"
			"8. Eliminar acta\n"
			"0. Salir\n"
			; 

		cin >> opcion; 
		switch (opcion)
		{
		case(1):
			crearNuevaActa();
			break;
		case(2):

			calcularNotaFinal();
			break;
		case(3):
			diligenciarCalificaciones();
			break;
		case(4):
			cerrarActa();
			break;
		case(5):
			submenuConsultaActas();
			break;
		case(6):
			submenuConsultaTrabajos();
			break;
		default:
			break;
		}
	} while (opcion>0);
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

