#pragma once
enum class TipoJurado
{
	externo, 
	interno
};

