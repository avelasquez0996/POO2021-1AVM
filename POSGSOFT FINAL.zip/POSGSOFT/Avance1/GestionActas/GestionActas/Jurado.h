#pragma once
#include "TipoJurado.h"
class Jurado
{
private:
	int  id;
	string nombre;
	TipoJurado tipoJurado;

public:
	int getId() {
		return this->id;
	}
	void setId(int id) {
		this-> id = id;
	}

	string getNombre() {
		return this->nombre;
	}
	void setNombre(string nombre) {
		this->nombre = nombre;
	}


	TipoJurado getTipoJurado() {
		return this->tipoJurado;
	}
	void setTipoJurado(TipoJurado tipoJurado) {
		this->tipoJurado = tipoJurado;
	}
};

