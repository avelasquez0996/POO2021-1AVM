#pragma once
#include "CriterioEvaluacion.h"
class Observacion
{
private:
	string observacionJ1;
	string observacionJ2;
	double calificacionJ1;
	double calificacionJ2;
	CriterioEvaluacion criterio;

public:
	string getObservacionJ1() {
		return this->observacionJ1;
	}
	void setObservacionJ1(string observacionJ1) {
		this->observacionJ1 = observacionJ1;
	}


	string getObservacionJ2() {
		return this->observacionJ2;
	}
	void setObservacionJ2(string observacionJ2) {
		this->observacionJ2 = observacionJ2;
	}


	double getCalificacionJ1() {
		return this->calificacionJ1;
	}
	void setCalificacionJ1(double calificacionJ1) {
		this->calificacionJ1 = calificacionJ1;
	}


	double getCalificacionJ2() {
		return this->calificacionJ2;
	}
	void setCalificacionJ2(double calificacionJ2) {
		this->calificacionJ2 = calificacionJ2;
	}

	CriterioEvaluacion getCriterio() {
		return this->criterio;
	}
	void setCriterio(CriterioEvaluacion criterio) {
		this->criterio = criterio;
	}

};

