#ifndef _JURADO_H
#define _JURADO_H
#include<string>
using namespace std;
class Jurado
{
private:
	long id;
	string nombre;
	string tipoJurado;
	string actasJurado[];
public:
	Jurado();
	~Jurado();
    void CrearJurado();
    void CriterioEvaluacion();
    long getId();
    void setID(long long int id);
    string getNombre();
    void setNombre(string nombre);
    string getTipo();
    void setTipo(string tipoJurado);
};
#endif
