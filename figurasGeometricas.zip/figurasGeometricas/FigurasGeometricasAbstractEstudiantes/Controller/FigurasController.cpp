#include "../Controller/FigurasController.h"
#include "../Model/FiguraGeometrica.h"
	#include "../Model/Circulo.h"
	#include "../Model/Triangulo.h"
	#include "../Model/Rectangulo.h"
	#include "../Model/Cuadrado.h"


	#include <iostream>
	#include <list>
	

	using std::cin;
	using std::cout;
	using std::endl;
	using std::list;
	

	class FigurasController
	{
	private:
	    //constante y estático para declararla constante para todos los objetos.
	    const static int MAX_ITEMS;
	    list<Rectangulo> listaRectangulo;
	    list<Circulo> listaCirculo;
	    list<Triangulo> listaTriangulo;
    list<Cuadrado> listaCuadrado;
	    list<FiguraGeometrica *> pListaFiguras; // Debe ser de apuntadores pq las clases abstractas no se pueden instanciar
	

	public:
	    // Retorna referencia a la lista de rectangulos
	    list<Rectangulo> &getListaRectangulo();
	    void agregarRectagulo(float largo, float ancho);
	

	    /**
	       * Retorna la referencia al rectangulo que tenga el mayor ancho       
	       *
	    */
	    Rectangulo &encontrarMayorAncho();
	

	    // TO-DO
	

	    list<Rectangulo> &getListaCirculo();
	    void agregarTriagulo(float base, float altura);
	    void agregarCirculo(float radio);


	    list<Cuadrado> &getListaCuadrado();
	    void agregarCuadrado(float lado);
	    
	};
	//#define FIGURAS_CONTROLLER_H
	#endif // FIGURASCONTROLLER_H

// Inicializacion constante estatica para elemento compartido
const int FigurasController::MAX_ITEMS = 10;

void FigurasController::agregarRectagulo(const float largo, const float ancho)
{
    if (listaRectangulo.size() < MAX_ITEMS)
    {
        cout << "Agrego rectangulo" << endl;
        Rectangulo *pRectTemp = new Rectangulo(largo, ancho);
        listaRectangulo.push_back(*pRectTemp);
    }
    else
    {
        //FIXME agregar manejo de excepcion
        std::cout << "\nSe sobrepasa el limite\n"
                  << std::endl;
    }
}

void FigurasController::agregarCirculo(float radio)
{
    if (listaCirculo.size() < MAX_ITEMS)
    {
        cout << "Agrego circulo" << endl;
    }
    else
    {
        //FIXME agregar manejo de excepcion
        std::cout << "\nSe sobrepasa el limite\n"
                  << std::endl;
    }
}

list<Rectangulo> &FigurasController::getListaRectangulo()
{
    // Creo la  referencia
    list<Rectangulo> &lista = listaRectangulo;
    return lista;
}

Rectangulo &FigurasController::encontrarMayorAncho()
{
    bool isFirst = true;
    int mayorAncho = 0;
    Rectangulo *pRectanguloMayor = NULL;
    for (list<Rectangulo>::iterator it = listaRectangulo.begin(); it != listaRectangulo.end(); ++it)
    {
        if (isFirst)
        {
            // Se inicializa el mayor ancho con el primer elemento
            int mayorAncho = listaRectangulo.begin()->getAncho();
            isFirst = false;
            pRectanguloMayor = &(*it); // It es un apuntador, para acceder al rectangulo se tiene que acceder al contenido
        }
        else
        {
            if (it->getAncho() > pRectanguloMayor->getAncho())
            {
                // Actaulizar el mayor
                pRectanguloMayor = &(*it);
            }
        }
    }
    // Se obtien el contenido del apuntador para luego retorar la referencia
    // a fin de facilitar el manejo de los objetos posteriormente
    return *pRectanguloMayor;

    
}