#include "Cuadrado.h"
	



	//Inicializa la variable A que es el área del cuadrado
	const float Cuadrado::A;
	
//Inicializa la variable L que es la longitud de un lado
const float Cuadrado::L;


	//CONSTRUCTORES CUADRADO
	Cuadrado::Cuadrado()
	{
	}
	

	Cuadrado:: Cuadrado (float area) : Cuadrado()
	{
	

	    this->area = area;
	}
	

	//METODOS CUADRADO
	

	void Cuadrado::calcularArea()
	{
	

	    this->area = (this->L * this->L);
	}
	

	void Cuadrado::calcularPerimetro()
	{
	

	    this->perimetro = (4 * A);
	}
	

	void Cuadrado::mostrarFigura()
	{
	    cout << "El área es: " << area << endl;
	    if (this->area == 0)
	    {
	        this->calcularArea();
	    }
	    if (this->perimetro == 0)
	    {
	        this->calcularPerimetro();
	    }
	

	    cout << "El area del cuadrado es: " << this->area << endl;
	    cout << "El perimetro del cuadrado es: " << this->perimetro << endl;
	    // LLamo al mostrarFigura delegado
	    FiguraGeometrica::mostrarFigura();
	}
	

	float Circulo::getLado() const
	{
	

	    return this->lado;
	}
	

	//CONSTRUCTORES TRIANGULO
	

	Triangulo::Triangulo() {}
	

	Triangulo::Triangulo(float base, float altura)
	{
	

	    this->base = base;
	    this->altura = altura;
	}
	

	//METODOS TRIANGULO
	

	void Triangulo::calcularArea()
	{
	    float area;
	    area = (base * altura) / 2;
	    std::cout << "El area del Triangulo es: " << area << std::endl;
	}
	

	void Triangulo::calcularPerimetro()
	{
	    float perimetro, temp;
	    temp = base / 2;
	    perimetro = 2 * ((sqrt((temp * temp)) + (altura * altura))) + base;
	    std::cout << "El perimetro del Triangulo es: " << perimetro << std::endl;
	}

	
	
	
	

