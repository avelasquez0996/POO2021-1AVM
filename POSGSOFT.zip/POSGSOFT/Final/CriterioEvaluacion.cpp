#ifndef _CRITERIODEEVALUACION_H
#define _CRITERIODEEVALUACION_H
#include "CriterioEvaluacion.h"
#include <string>
#include <iostream>
using namespace std;

CriterioEvaluacion::CriterioEvaluacion(){
	identificador[8] = {1,2,3,4,5,6,7,8};
    descripcion[8] = {"Desarrollo y profundidad en el tratamiento del tema","Desaf�o acad�mico y cient�fico del tema","Cumplimiento de los objetivos propuestos","Creatividad e innovaci�n de las soluciones y desarrollos propuestos","Validez de los resultados y conclusiones","Manejo y procesamiento de la informaci�n y bibliograf�a","Calidad y presentaci�n del documento escrito","Presentaci�n oral"};
    porcentaje[8] = {0.2, 0.15, 0.1, 0.1, 0.2, 0.1, 0.075, 0.075};
    observacion[8] = {0,0,0,0,0,0,0,0};
    calificacion[8] = {0,0,0,0,0,0,0,0};
    notaEvaluacion = 0;
}

CriterioEvaluacion::~CriterioEvaluacion(){
	
}

CriterioEvaluacion::CrearCriterio(){
	double val=0;
	string val2=" ";
	for(int i=0; i<8;i++){
    cout << "Criterio " << identificador[i] << endl;
    cout << "Descripcion: " << descripcion[i] << endl;
	cout << "Ingrese la observacion: \n";
    cin>>val2;
    observacion[i]=val2;
    cout << "Ingrese la nota para este criterio: \n";
    cin>>val;
    calificacion[i]=val;}
};

CriterioEvaluacion::obtenerEvaluacion(){
	double valor=0;
	for(int i=0; i<8;i++){
	valor = (porcentaje[i]*calificacion[i])+ valor;
	}
	notaEvaluacion=valor;
}

CriterioEvaluacion::getnotaEva(){
	return this->notaEvaluacion;
}




