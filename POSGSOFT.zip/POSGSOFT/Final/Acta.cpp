#include "Acta.h"
#include <string>
#include <iostream>
using namespace std;

Acta::Acta(){
    numero = 0;
    fecha = " ";
    autor = " ";
    nombreTrabajo = " ";
    tipoTrabajo = " ";
    periodo = 0;
    director = " ";
    codirector = " ";
    estado= " ";
    notaFinal=0,0;
};

Acta::~Acta(){
	
}

void Acta::CrearActa(){
	int val=0;
	string val2=" ";
	int cond=1;
	cout << "Ingrese el numero de la acta:\n";
	cin >> val;
	numero=val;
	cout << "Ingrese la fecha de la acta (dd/mm/aaaa):\n";
    cin >> val2;
    fecha=val2;
    cout << "Ingrese el autor del acta:\n";
    cin >> val2;
    autor=val2;
    cout << "Ingrese el nombre del trabajo:\n";
    cin >> val2;
	nombreTrabajo=val2;
	while(cond==1){
    cout << "Ingrese el tipo de trabajo | Aplicado = A | Investigaci�n = I\n";
    cin >> val2;
    if(val2 == "A" || val2== "a"){
    tipoTrabajo="Aplicado";cond=2;}
	if (val2 == "I"|| val2== "i"){
	tipoTrabajo="Investigaci�n";cond=2;}
	else {
	cout << "�Ingrese una opci�n valida!\n";
	}
	}
	cout << "Ingrese el periodo del acta:\n";
    cin >> val;
    periodo=val;
    cout << "Ingrese el nombre del director del acta:\n";
    cin >> val2;
    director=val2;
    while(cond==2){
    cout << "Quiere a�adir un codirector? | SI = S | NO = N\n";
    cin >> val2;
    if(val2 == "S" || val2== "s"){
    cout << "Ingrese el nombre del Codirector del acta:\n";
    cin>>val2;
    codirector=val2;
	cond=3;}
	if (val2 == "N"|| val2== "n"){
	codirector="NA";cond=3;}
	else {
	cout << "�Ingrese una opci�n valida!\n";}
	}
	while(cond==3){
    cout << "Ingrese el estado de trabajo | Abierto = A | Cerrado = C\n";
    cin >> val2;
    if(val2 == "A" || val2== "a"){
    estado="Abierto";cond=4;}
	else if (val2 == "C"|| val2== "c"){
	estado="Cerrado";cond=4;}
	else {cout << "�Ingrese un estado valido!\n";}
	}
}

int Acta::getNumero() {
    return this->numero;
}
void Acta::setNumero(int numero) {
    this->numero = numero;
}

string Acta::getFecha() {
    return this->fecha;
}
void Acta::setFecha(string fecha) {
    this->fecha = fecha;
}

string Acta::getAutor() {
    return this->autor;
}
void Acta::setAutor(string autor) {
	this->autor = autor;
}

string Acta::getNombreTrabajo() {
    return this->nombreTrabajo;
}
void Acta::setNombreTrabajo(string nombreTrabajo) {
	this->nombreTrabajo = nombreTrabajo;
}

string 	Acta::getTipoTrabajo(){
    return this->tipoTrabajo;
}
void Acta::setTipoTrabajo(string tipoTrabajo) {
    this->tipoTrabajo = tipoTrabajo;
}

int Acta::getPeriodo() {
	return this->periodo;
}
void Acta::setPeriodo(int periodo) {
    this->periodo = periodo;
}

string Acta::getDirector() {
    return this->director;
}
void Acta::setDirector(string director) {
    this->director = director;
}

string Acta::getCodirector() {
    return this->codirector;
}
void Acta::setCodirector(string codirector) {
    this->codirector = codirector;
}

string Acta::getEstado()  {
    return this->estado;
}
void Acta::setEstado(string estado) {
   	this->estado = estado;
}

double Acta::getnotaFinal() {
    return this->notaFinal;
}
void Acta::setnotaFinal(double notaFinal) {
   	this->notaFinal = notaFinal;
}
