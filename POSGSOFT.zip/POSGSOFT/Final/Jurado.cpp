#include "Jurado.h"
#include <string>
#include <iostream>
using namespace std;

Jurado::Jurado(){
	id=0;
    nombre= " ";
    tipoJurado= " ";
};

Jurado::~Jurado(){
	
}

Jurado::CrearJurado(){
	int val=0;
	string val2=" ";
	long long int val3=0;
	int cond=1;
	cout << "Ingrese el id del jurado:\n";
	cin >> val3;
	id=val3;
	cout << "Ingrese el nombre del jurado:\n";
	cin >> val2;
	nombre=val2;
	while(cond==1){
    cout << "Ingrese el tipo de jurado | Interno = I | Externo = E\n";
    cin >> val2;
    if(val2 == "I" || val2== "i"){
    tipoJurado="Interno";cond=2;}
	else if (val2 == "E"|| val2== "e"){
	tipoJurado="Externo";cond=2;}
	else {cout << "�Ingrese una opcion valida!\n";}
	}
	while(cond==2){
    cout << "�El jurado ya ha sido jurado? : | Si = S | No = N\n";
    cin >> val2;
    if(val2 == "S" || val2== "s"){
    cout << "Ingrese el numero de actas de las cuales ha sido jurado : \n";
    cin >> val;
    for(int i=0; i<val;i++){
    cout << "Ingrese el numero de la acta "<<i+1<<":";
    cin>>val;
    actasJurado[i]=val;}
	cond=3;}
	else if (val2 == "N"|| val2== "n"){
	cond=3;}
	else {cout << "�Ingrese una opcion valida!\n";}
	}
}

Jurado::getId(){
	return this->id;
}
Jurado::setID(long long int id){
	this->id = id;
}

Jurado::getNombre(){
	return this->nombre;
}
Jurado::setNombre(string nombre){
	this->nombre = nombre;
}

Jurado::getTipo(){
	return this->tipoJurado;
}
Jurado::setTipo(string tipoJurado){
	this->tipoJurado = tipoJurado;
}




