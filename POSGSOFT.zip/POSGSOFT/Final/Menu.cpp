#include "Acta.h"
#include "Jurado.h"
#include "CriterioEvaluacion.h"
#include <iostream>
#include <string>
using namespace std;
int main()
{
	Acta obj;
	Jurado jur1;
	Jurado jur2;
	CriterioEvaluacion cri1;
	CriterioEvaluacion cri2;
	
	int opcion;
	do
	{
		cout << "Digite el numero de la opcion que desee llevar a cabo\n"
			"1. Crear nueva acta\n"
			"2. Diligenciar calificaciones acta\n"
			"3. Cerrar acta\n"
			"4. Consulta actas\n"
			"5. Consulta trabajos\n"
			"6. Consulta jurados\n"
			"7. Eliminar acta\n"
			"0. Salir\n"
			; 

		cin >> opcion; 
		switch (opcion)
		{
		case(1):
			cout << "CREAR ACTA:\n";
			obj.CrearActa();
			cout << "INGRESAR DATOS JURADO 1:\n";
			jur1.CrearJurado();
			cout << "INGRESAR DATOS JURADO 2:\n";
			jur2.CrearJurado();
			break;
		case(2):
			cout << "CRITERIO EVALUACION JURADO 1:\n";	
			cri1.CrearCriterio();	
			cout << "CRITERIO EVALUACION JURADO 2:\n";	
			cri2.CrearCriterio();
			cri1.obtenerEvaluacion();
			cri2.obtenerEvaluacion();
			obj.setnotaFinal((getnotaEva()+cri2.getnotaEva())/2);
			break;
		case(3):
			obj.setEstado("CERRADA");
			break;
		case(4):
			obj.getNumero();
			break;
		case(5):
			obj.getNombreTrabajo();
			break;
		case(6):
			jur1.getNombre();
			jur2.getNombre();
			break;
		case(7):
		 	delete obj;
			break;
		case(0):
			exit(0);
			break;
		default:
			break;
		}
		system("PAUSE");
		return 0;
	} while (opcion>0);
    
}
