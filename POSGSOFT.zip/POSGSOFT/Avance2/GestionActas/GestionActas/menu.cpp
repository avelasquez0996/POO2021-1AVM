#include "Acta.h"
#include "Jurado.h"
#include <iostream>
#include <string>
using namespace std;
int main()
{
	Acta obj;
	Jurado jur1;
	Jurado jur2;
	int opcion, val, cond=1;
	string val2;
	long long int val3;
	do
	{
		cout << "Digite el numero de la opcion que desee llevar a cabo\n"
			"1. Crear nueva acta\n"
			"2. Diligenciar calificaciones acta\n"
			"3. Cerrar acta\n"
			"4. Consulta actas\n"
			"5. Consulta trabajos\n"
			"6. Consulta jurados\n"
			"7. Eliminar acta\n"
			"0. Salir\n"
			; 

		cin >> opcion; 
		switch (opcion)
		{
		case(1):
			//ACTAS:
			cout << "Ingrese el numero de la acta:\n";
			cin >> val;
			obj.setNumero(val);
			cout << "Ingrese la fecha de la acta(dd/mm/aaaa):\n";
        	cin >> val2;
        	obj.setFecha(val2);
        	cout << "Ingrese el autor del acta:\n";
        	cin >> val2;
        	obj.setAutor(val2);
        	cout << "Ingrese el nombre del trabajo:\n";
        	cin >> val2;
        	obj.setNombreTrabajo(val2);
        	while(cond==1){
        	cout << "Ingrese el tipo de trabajo | Aplicado = A | Investigaci�n = I\n;
        	cin >> val2;
        	if(val2 == "A" || val2== "a"){
        	obj.setTipoTrabajo("Aplicado");
        	cond=2;}
			else if (val2 == "I"|| val2== "i"){
			obj.setTipoTrabajo("Investigaci�n");
			cond=2;
			}
			else {
				cout << "�Ingrese un tipo de trabajo valido!\n";
			}}
			cout << "Ingrese el periodo del acta:\n;
        	cin >> val;
        	obj.setPeriodo(val);
        	//DIRECTOR DEL ACTA:
			cout << "Ingrese el director del acta:\n;
        	cin >> val2;
        	obj.setDirector(val2);
        	//CODIRECTOR DEL ACTA:
        	cout << "Ingrese el codirector del acta:\n;
        	cin >> val2;
        	obj.setCodirector(val2);
        	cout << "Ingrese la nota final del acta:\n;
        	cin >> val;
        	obj.setNotaFinal(val);
        	cout << "Ingrese la nota final del acta:\n;
        	cin >> val;
        	obj.setNotaFinal(val);
        	while(cond==2){
        	cout << "Ingrese el estado de trabajo | Abierto = A | Cerrado = C\n;
        	cin >> val2;
        	if(val2 == "A" || val2== "a"){
        	obj.setEstado("Abierto");
        	cond=3;}
			else if (val2 == "C"|| val2== "c"){
			obj.setEstado("Cerrado");
			cond=3;
			}
			else {
				cout << "�Ingrese un estado valido!\n";
			}}
			obj.setEstadoTrabajo(obj.getEstado());
        	cout << "Ingrese la nota final del acta:\n;
        	cin >> val;
        	obj.setNotaFinal(val);
        	
        	//JURADO 1:
        	cout << "Ingrese el id del jurado 1:\n;
        	cin >> val3;
        	jur1.setId(val3);
        	cout << "Ingrese el nombre del jurado 1:\n;
        	cin >> val2;
        	jur1.setNombre(val2);
        	while(cond==3){
        	cout << "Ingrese el tipo del jurado 1 | Interno = I | Externo =  E\n;
        	cin >> val2;
        	if(val2 == "I" || val2== "i"){
        	jur1.setTipoJurado("Interno");
        	cond=4;}
			else if (val2 == "E"|| val2== "e"){
			jur1.setTipoJurado("Externo");
			cond=4;
			}
			else {
				cout << "�Ingrese un tipo de jurado valido!\n";
			}}
			//JURADO 2:
        	cout << "Ingrese el id del jurado 2:\n;
        	cin >> val3;
        	jur2.setId(val3);
        	cout << "Ingrese el nombre del jurado 2:\n;
        	cin >> val2;
        	jur2.setNombre(val2);
        	while(cond==5){
        	cout << "Ingrese el tipo del jurado 2 | Interno = I | Externo =  E\n;
        	cin >> val2;
        	if(val2 == "I" || val2== "i"){
        	jur2.setTipoJurado("Interno");
        	cond=6;}
			else if (val2 == "E"|| val2== "e"){
			jur2.setTipoJurado("Externo");
			cond=6;
			}
			else {
				cout << "�Ingrese un tipo de jurado valido!\n";
			}}
			break;
		case(2):
			calcularNotaFinal();
			break;
		case(3):
			diligenciarCalificaciones();
			break;
		case(4):
			cerrarActa();
			break;
		case(5):
			submenuConsultaActas();
			break;
		case(6):
			submenuConsultaTrabajos();
			break;
		default:
			break;
		}
	} while (opcion>0);
    
}
