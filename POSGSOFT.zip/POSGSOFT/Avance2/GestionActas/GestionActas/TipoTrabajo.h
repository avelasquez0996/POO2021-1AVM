#pragma once
enum  class TipoTrabajo
{
	Aplicado,
	Investigaci�n
};

