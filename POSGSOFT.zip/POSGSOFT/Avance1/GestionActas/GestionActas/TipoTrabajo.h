#pragma once
enum  class TipoTrabajo
{
	Aplicado,
	Investigacion
};

