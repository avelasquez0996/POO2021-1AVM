#pragma once
enum class EstadoTrabajo
{
	aprobado,
	pendiente,
	rechazado
};

