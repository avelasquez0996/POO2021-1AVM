#pragma once
#include<string>
using namespace std;

class CriterioEvaluacion
{
private:
	int identificador;
	string descripcion;
	double porcentaje;
public:
	int getIdentificador() {
		return this->identificador;
	}
	void setIdentificador(int identificador) {
		this->identificador = identificador;
	}


	string getDescripcion() {
		return this->descripcion;
	}
	void setDescripcion(string descripcion) {
		this->descripcion = descripcion;
	}


	double getPorcentaje() {
		return this->porcentaje;
	}
	void setPorcentaje(double porcentaje) {
		this->porcentaje = porcentaje;
	}
};

