#pragma once
enum class Estado
{
	abierto,
	cerrado
};

