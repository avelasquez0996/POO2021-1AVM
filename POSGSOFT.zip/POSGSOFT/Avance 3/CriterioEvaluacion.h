#ifndef _CRITERIOEVALUACION_H
#define _CRITERIOEVALUACION_H
#include<string>
using namespace std;
class CriterioEvaluacion
{
private:
	int identificador[8];
	string descripcion[8];
	double porcentaje[8];
	string observacion[8];
	double calificacion[8];
	double notaEvaluacion;
	
public:
	CriterioEvaluacion();
	~CriterioEvaluacion();
	void CrearCriterio();
	void obtenerEvaluacion();
	double getnotaEva();
};
#endif

