#ifndef _ACTA_H
#define _ACTA_H
#include<string>
using namespace std;
class Acta
{
private:
	int numero;
	string fecha;
	string autor;
	string nombreTrabajo;
	string tipoTrabajo;
	int periodo;
	string director;
	string codirector;
	string estado;
	double notaFinal;
public:
    Acta();
    ~Acta();
    void CrearActa();
    int getNumero();
    void setNumero(int numero);
    string getFecha();
    void setFecha(string fecha);
    string getAutor();
    void setAutor(string autor);
    string getNombreTrabajo();
    void setNombreTrabajo(string nombreTrabajo);
    string getTipoTrabajo();
    void setTipoTrabajo(string tipoTrabajo);
    int getPeriodo();
    void setPeriodo(int periodo);
    string getDirector();
    void setDirector(string director);
    string getCodirector();
    void setCodirector(string codirector);
   	string getEstado();
    void setEstado(string estado);
    double getnotaFinal();
    void setnotaFinal(double notaFinal);
};
#endif
  




