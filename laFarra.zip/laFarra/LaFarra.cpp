#include <string>
#include <iostream>
using namespace std;

// Declaraciones
class Producto
{
private:
    std::string nombre;

public:
    Producto();
    Producto(std::string);
    void mostrarProducto();
};
Producto::Producto(){
}
class Tienda
{
private:
    Producto listaProductos[10];
    std::string nombreDueno;

public:
    Tienda();
    void mostrarTodosProductos();
    
};
Tienda :: Tienda(){
}
class Cliente 
{
	private 
		string std:: nombre ;
		string std:: email;
		int std :: id;
		int std:: cantidadLitrosTomados;
		int std:: telefono;
		
	public
		Cliente ();
		void darReporteCliente
		
};
		Cliente ::Cliente(){
			
		}
Cliente::Cliente(std::string nombre, string email, int id , int telefono){
		
	this->nombre = nombre;
	this->email = email;
	this->id = id;
	this->telefono = telefono;	
}
		
	void Cliente:: mostrarReporteCliente(){
			std::cout << "El cliente es " << this->nombre;
			std::cout << "email " << this->email;
			std::cout << "El id es " << this->id;
			std::cout << "La cantidad de litros tomados es de  " << this->cantidadLitrosTomados;
			
		}
		
		
		
		
class DetalleVenta{
	Detalle::Venta(std::string cliente, string producto, int valor, int cantidadProducto)
	this->cliente = cliente;
	this->producto = producto;
	this->valor = valor;
	this->cantidadProducto = cantidadProducto;	
	
	
	private 
	string cliente;
	string producto;
	int valor;
	int cantidadProducto;
	
		DetalleVenta();
		public
		
		DetalleVenta ::DetalleVenta(){
	
	
	
	}

		
	
	
		
		void DetalleVenta darReporteVentas(){
		std::cout << "El cliente es " << this->Cliente;
			std::cout << "email " << this->producto;
			std::cout << "El id es " << this->valor;
			std::cout << "La cantidad de productos es de " << this->CantidadProductos;		
			
			
		}
			darReporteVentas()
		};
		
		
		
	


// Implementaci�n m�todos de la clase producto
Producto::Producto() {}

Producto::Producto(std::string nombre)
{
    this->nombre = nombre;
}

void Producto::mostrarProducto()
{
    std::cout << "El producto es " << this->nombre;
}

// Implementacion metodos de la tienda
Tienda::Tienda()
{
    this->listaProductos[0] = Producto("producto1");
    this->listaProductos[1] = Producto("producto2");
    std::cout << "Cree la tienda" << std::endl;
}

void Tienda::mostrarTodosProductos()
{

    for (int i = 0; i < 2; i++)
    {
        //Se usa el  m�todo que tiene cada producto para mostrar su informaci�
        listaProductos[i].mostrarProducto();
    }
}
class Licor {
Licor (std:: int litrosLicor, float porcentajeAlcohol string porcentajeAlcohol );

Licor::


	
	private
	int litrosdeLicor;
	float porcentajeAlcohol;
	string tipoLicor;
	public 
	
	
	void 
	Licor (std:: int litrosLicor, float porcentajeAlcohol string tipoLicor );
	this->litrosLicor = litrosLicor;
	this-> porcentajeAlcohol =  porcentajeAlcohol;
	this->tipoLicor = tipoLicor;	
	
	int mostrarReporteLicor (){
		
	std::cout << "Los litros de licor son " << this->litrosLicor;
	std::cout << "El porcentaje de alcohol es  " << this->;porcentajeAlcohol;
	std::cout << "El tipo de licor es  " << this->tipoLicor;
	}
		Licor :: Licor (){
			
		}
};

Licor::Licor;
int main()
{
    // Crear la tienda
    Tienda laFarra;

    //Usar uno de los metodos de la tienda, que permite tambi�n luego
    // mostrar los productos
    laFarra.mostrarTodosProductos();
    return 0;
}
