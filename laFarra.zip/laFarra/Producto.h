#include <string>
#include <iostream>
using namespace std;

// Declaraciones
class Producto
{
private:
    std::string nombre;

public:
    Producto();
    Producto(std::string);
    void mostrarProducto();
};
Producto::Producto(){
}
