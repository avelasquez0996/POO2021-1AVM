#include <string>
#include <iostream>
using namespace std;


class Cliente 
{
	private 
		string std:: nombre ;
		string std:: email;
		int std :: id;
		int std:: cantidadLitrosTomados;
		int std:: telefono;
		
	public
	Cliente ();
	void Cliente darReporteCliente()
		
};
		Cliente ::Cliente(){
			
		}

