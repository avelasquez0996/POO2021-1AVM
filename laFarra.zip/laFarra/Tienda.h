#include <string>
#include <iostream>
using namespace std;



class Tienda
{
private:
    Producto listaProductos[10];
    std::string nombreDueno;

public:
    Tienda();
    void mostrarTodosProductos();
    
};
Tienda :: Tienda(){
}
