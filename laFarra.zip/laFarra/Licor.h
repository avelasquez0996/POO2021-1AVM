#include <string>
#include <iostream>
using namespace std;



class Licor {
Licor (std:: int litrosLicor, float porcentajeAlcohol string porcentajeAlcohol );

Licor::


	
	private
	int litrosdeLicor;
	float porcentajeAlcohol;
	string tipoLicor;
	public 
	
	
	void 
	Licor (std:: int litrosLicor, float porcentajeAlcohol string tipoLicor );
	this->litrosLicor = litrosLicor;
	this-> porcentajeAlcohol =  porcentajeAlcohol;
	this->tipoLicor = tipoLicor;	
	
	int mostrarReporteLicor (){
		
	std::cout << "Los litros de licor son " << this->litrosLicor;
	std::cout << "El porcentaje de alcohol es  " << this->;porcentajeAlcohol;
	std::cout << "El tipo de licor es  " << this->tipoLicor;
	}
		Licor :: Licor (){
			
		}
};

Licor::Licor;
int main()
{
