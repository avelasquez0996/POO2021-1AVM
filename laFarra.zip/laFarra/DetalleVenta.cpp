





#include <string>
#include <iostream>
using namespace std;

class DetalleVenta{
	Detalle::Venta(std::string cliente, string producto, int valor, int cantidadProducto)
	this->cliente = cliente;
	this->producto = producto;
	this->valor = valor;
	this->cantidadProducto = cantidadProducto;	
	
	
	private 
	string cliente;
	string producto;
	int valor;
	int cantidadProducto;
	
		DetalleVenta();
		public
		
		DetalleVenta ::DetalleVenta(){
	
	
	
	}

		
	
	
		
		void DetalleVenta darReporteVentas(){
		std::cout << "El cliente es " << this->Cliente;
			std::cout << "email " << this->producto;
			std::cout << "El id es " << this->valor;
			std::cout << "La cantidad de productos es de " << this->CantidadProductos;		
			
			
		}
			darReporteVentas()
		};
		
